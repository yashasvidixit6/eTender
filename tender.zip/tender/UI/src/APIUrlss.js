

export const _userapiurl = "http://localhost:3001/user/";

export const _categoryapiurl ="http://localhost:3001/category/";
export const _subcategoryapiurl ="http://localhost:3001/subcategory/";
