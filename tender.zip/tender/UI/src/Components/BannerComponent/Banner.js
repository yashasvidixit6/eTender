import './Banner.css';
import { useState , useEffect } from 'react';

function Banner(){

  const [ BannerContent , setBannerContent ] = useState();   


  useEffect(()=>{

    const token =localStorage.getItem("token");
    const role=localStorage.getItem("role");
     
      if(token!=undefined )
    {
    
      setBannerContent(<></>);
    }
     else 
    {
      setBannerContent(<>
      
      
      {/* slider section */}
  <section class="slider_section position-relative">
    <div id="customCarousel1" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <div class="img_container">
            <div class="img-box">
              <img src="./assets/images/banner1.jpg"  class="" alt="..."/>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="img_container">
            <div class="img-box">
              <img src="./assets/images/banner1.jpg" class="" alt="..."/>
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="img_container">
            <div class="img-box">
              <img src="./assets/images/banner1.jpg" class="" alt="..."/>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel_btn_box">
        <a class="carousel-control-prev" href="#customCarousel1" role="button" data-slide="prev">
          <i class="fa fa-arrow-left" aria-hidden="true"></i>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#customCarousel1" role="button" data-slide="next">
          <i class="fa fa-arrow-right" aria-hidden="true"></i>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </div>
    <div class="detail-box">
      <div class="col-md-8 col-lg-6 mx-auto">
        <div class="inner_detail-box">
          <h1>
           Online Tender  <br></br>
            Site
          </h1>
          <p>
            We Provide Solution On <br></br>
            Your Tenders
          </p>
          <div>
            <a href="" class="slider-link">
              CONTACT US
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* end slider section */}
     
      </>);
    
    }
    
  });
      
  
    


    return(
        <>
        
        { BannerContent}
        
        
        </>
    );
}

export default Banner;