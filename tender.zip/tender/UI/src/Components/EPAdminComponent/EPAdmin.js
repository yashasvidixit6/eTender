import './EPAdmin.css';
import { useState , useEffect } from 'react';
import { _userapiurl } from '../../APIUrlss';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


function EPAdmin() {


    const navigate = useNavigate();  
    const [ name , setName ] = useState();
    const [ email , setEmail ] = useState();    
    const [ mobile , setMobile ] = useState();
    const [ address , setAddress ] = useState();
    const [ city , setCity ] = useState();
    const [ gender , setGender ] = useState();
    const [ m , setM ] = useState();
    const [ f , setF ] = useState();
    const [ output , setOutput ] = useState();

    useEffect(()=>{
        var condition_obj={"_id":localStorage.getItem("_id")};
        axios.get(_userapiurl+"fetch",{
            params : { condition_obj : condition_obj }
        }).then((response)=>{
            var userDetails=response.data.response_content[0];
            setName(userDetails.name);
            setEmail(userDetails.email);
            setMobile(userDetails.mobile);
            setAddress(userDetails.address);
            setCity(userDetails.city);
            if(userDetails.gender=="male")
             setM("checked");
            else
             setF("checked");
            console.log(userDetails);
        }).catch((error)=>{
            console.log(error);
        });    
    },[]);          

    const handlesubmit=()=>{

      
      var update_details={"condition_obj":{"email":email} ,"content_obj":{"name":name,"mobile":mobile,"address":address,"city":city,"gender":gender}};
      axios.patch(_userapiurl+"update",update_details).then((response)=>{
          alert("User Profile Edited Successfully");
          navigate("/epadmin");
      });


    };
    
  return (
    <>
        {/* About Start */}
        <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
<h1 class="display-5 mb-4">Edit Profile <span class="text-primary">Here</span></h1>
<font color="blue">{output}</font>
<form>
  <div class="form-group">
    <label for="name">Name:</label>
    <input type="text" class="form-control" value={name} onChange={ e => setName(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" value={email} onChange={ e => setEmail(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="mobile">Mobile:</label>
    <input type="text" class="form-control" value={mobile} onChange={ e => setMobile(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="address">Address:</label>
    <textarea rows="5" class="form-control" value={address} onChange={ e => setAddress(e.target.value) } ></textarea>
  </div>
  <br/>
  <div class="form-group">
    <label for="city">City:</label>
    <select class="form-control" value={city} onChange={ e => setCity(e.target.value) } >
        <option>Select City</option>
        <option>Indore</option>
        <option>Bhopal</option>
        <option>Ujjain</option>
    </select>
  </div>
  <br/>
  <div class="form-group">
    <label for="gender">Gender:</label>
    &nbsp;&nbsp;
    Male <input type="radio" name="gender" checked={m} value="male" onChange={ e => setGender(e.target.value) }  /> &nbsp;&nbsp;
    Female <input type="radio" name="gender" checked={f} value="female" onChange={ e => setGender(e.target.value) } />
  </div>
  <br/>
  <button type="button" class="btn btn-success" onClick={ ()=> handlesubmit() }>Submit</button>
</form>
            </div>
        </div>
    </div>
    {/* About End */}
    </>
   );
}

export default EPAdmin;