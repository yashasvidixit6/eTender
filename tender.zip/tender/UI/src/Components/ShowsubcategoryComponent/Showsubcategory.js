import './Showsubcategory.css';
import { useState , useEffect } from 'react';
import axios from 'axios';
import { _categoryapiurl , _subcategoryapiurl } from '../../APIUrlss';
import { Link , useParams } from 'react-router-dom';

function Showsubcategory() {

 const params = useParams(); 
 const [ subcategory , setSubCategoryDetails ] = useState([]);
 
 useEffect(()=>{
  var condition_obj={"catnm":params.catnm};
  axios.get(_subcategoryapiurl+"fetch",{
      params : { condition_obj : condition_obj }
   }).then((response)=>{
      console.log(response.data.response_content);
      setSubCategoryDetails(response.data.response_content);
   }).catch((error)=>{
      console.log(error);
   });    
  },[]);

    
  return (
    <>
        {/* About Start */}
        <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
<h1 class="display-5 mb-4">SubCategory <span class="text-primary">List</span> &gt;&gt; {params.catnm} </h1>
<center>
<div id="main">
{ 
subcategory.map((row)=>(
  <Link to="" >
  <div class="part">
    <img src={`../assets/uploads/subcaticons/${row.subcaticonnm}`} height="100" width="150" />
    <br/>
    <b>{row.subcatnm}</b>    
  </div>
  </Link>
 )) 
}

</div>
</center>

            </div>
        </div>
    </div>
    {/* About End */}
    </>
   );
}

export default Showsubcategory;