import './Showcategory.css';
import { useState , useEffect } from 'react';
import axios from 'axios';
import { _categoryapiurl , _subcategoryapiurl } from '../../APIUrlss';
import { Link } from 'react-router-dom';

function Showcategory() {

 const [ category , setCategoryDetails ] = useState([]);
 
 useEffect(()=>{
    axios.get(_categoryapiurl+"fetch").then((response)=>{
        setCategoryDetails(response.data.response_content);
    }).catch((error)=>{
        console.log(error);
    });    
  },[]);    
    
  return (
    <>
        {/* About Start */}
        <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
<h1 class="display-5 mb-4">Category <span class="text-primary">List</span> &gt;&gt;</h1>
<center>
<div id="main">
{ 
category.map((row)=>(
  <Link to={`/showsubcategory/${row.catnm}`} >
  <div class="part">
    <img src={`./assets/uploads/caticons/${row.caticonnm}`} height="100" width="150" />
    <br/>
    <b>{row.catnm}</b>    
  </div>
  </Link>
 )) 
}

</div>
</center>

            </div>
        </div>
    </div>
    {/* About End */}
    </>
   );
}

export default Showcategory;