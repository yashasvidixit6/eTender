import './Nav.css';
import { Link } from 'react-router-dom';
import { useState , useEffect } from 'react';


function Nav() {

    const [ NavContent , setNavContent ] = useState();    
  
    useEffect(()=>{
        const token=localStorage.getItem("token");
        const role=localStorage.getItem("role");
        if(token!=undefined && role=="admin")    
        {
            setNavContent(    <>
                {/* Navbar Start */}
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark shadow-sm px-5 py-3 py-lg-0">
                
                <a class="navbar-brand p-0">
                    <h1 class="m-0 text-uppercase text-primary"><i class="far fa-smile text-primary me-2"></i>Tenders</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="navbar-toggler-icon"></span>
           x     </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0 me-n3">
                        <a class="nav-item nav-link active"><Link to="/admin">Admin Home</Link></a>
                        <a class="nav-item nav-link"><Link to="/manageusers">Manage User</Link></a>
                         <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Settings</button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" ><Link to ="/epadmin">Edit Profile</Link></a>
                            <a class="dropdown-item" ><Link to ="/cpadmin">Change Password</Link></a>
                            <a class="nav-item nav-link"><Link to="/logout">Logout</Link></a>
                     </div>
                     <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Manage Category</button>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" ><Link to ="/addcategory">Addcategory</Link></a>
                            <a class="dropdown-item" ><Link to ="/addsubcategory">Addsubcategory</Link></a>
                            </div>
                       </div>

                        </div> 
                    </div>
                </div>
            </nav>
            {/* Navbar End */}
            </>);
        }
        else if(token!=undefined && role=="user")    
        {
            setNavContent(    <>
                {/* Navbar Start */}
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark shadow-sm px-5 py-3 py-lg-0">
                <a class="navbar-brand p-0">
                    <h1 class="m-0 text-uppercase text-primary"><i class="far fa-smile text-primary me-2"></i>Tenders</h1>
                </a>
                

                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0 me-n3">
                        <a class="nav-item nav-link active"><Link to="/user">User Home</Link></a>
                        <a class="nav-item nav-link "><Link to="/showcategory">Search Tender</Link></a>
                        
                        <div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Settings
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a class="dropdown-item" ><Link to ="/epuser">Edit Profile</Link></a>
    <a class="dropdown-item" ><Link to ="/cpuser">Change Password</Link></a>
    
  </div>
</div>

                        <a class="nav-item nav-link"><Link to="/logout">Logout</Link></a>
                    </div>
                </div>
            </nav>
            {/* Navbar End */}
            </>);        
        }
        else
        {
            setNavContent(    <>
                {/* Navbar Start */}
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark ">
                <a class="navbar-brand p-0">
                    <h1 class="m-0 text-uppercase text-primary"><i class="far fa-smile text-primary me-2"></i>Tenders</h1>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-expanded="false">
                    <span class="navbar-toggler-icon"></span>
           x     </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0 me-n3"  >
                        <a class="nav-item nav-link active"><Link to="/">Home</Link></a>
                        <a class="nav-item nav-link"><Link to="/about">About</Link></a>
                        <a class="nav-item nav-link"><Link to="/contact">Contact</Link></a>
                        <a class="nav-item nav-link"><Link to="/service">Service</Link></a>
                        <a class="nav-item nav-link"><Link to="/register">Register</Link></a>
                        <a class="nav-item nav-link"><Link to="/login">Login</Link></a>
                       
                    </div>
                </div>
            </nav>
            {/* Navbar End */}
            </>);    
        }
  }); 
    

  return (
    <>
      
        { NavContent }
    </>
   );
}

export default Nav;