import './Content.css';
function Content() {
  return (
    <>
      <div id ="Content"><h1> content section</h1>
      <a href="#Content">this is Content Section!</a> 
      </div>
    </>
  );
}
export default Content;
