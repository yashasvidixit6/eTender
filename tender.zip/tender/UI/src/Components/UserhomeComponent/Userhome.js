import './Userhome.css';

function Userhome() {
  return (
  <>
    
  {/* about section */}

  <section class="about_section layout_padding ">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="img-box">
            <img src="./assets/images/about-img.jpg" alt=""/>
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                UserHome  Panel
              </h2>
            </div>
           </div>
        </div>
      </div>
    </div>
  </section>

  {/* end about section */}
          
              

  
  </>
  );
}

export default Userhome;