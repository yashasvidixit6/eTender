import { Navigate , useParams } from 'react-router-dom';
import { useState , useEffect } from 'react';
import { _userapiurl } from '../../APIUrlss';
import axios from 'axios';

function Verifyuser()
{

    const params = useParams(); 

    useEffect(()=>{
     var condition_obj={"email":params.email};   
     axios.get(_userapiurl+"fetch",{
        params : { condition_obj : condition_obj }   
     }).then((response)=>{
        if(response.data.response_content[0].__v==0)
        {
            var updateDetails={"condition_obj":{"email":params.email},"content_obj":{"status":1,"__v":1}}; 
            axios.patch(_userapiurl+"update",updateDetails).then((response)=>{
               console.log("User verified....");    
            });    
        }       
     });
    },[]);

    return(
        <div>
            <Navigate to='/login' />
        </div>
    )
}

export default Verifyuser;