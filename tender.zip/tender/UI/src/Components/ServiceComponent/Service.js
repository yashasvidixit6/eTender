import './Service.css';

function Service() {
  return (
    <>
            {/* About Start */}
            <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
                <h1 class="display-5 mb-4">Welcome To <span class="text-primary">TENDERS</span>, Service Page</h1>
                <p style={{"text-align":"justify"}} >Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cupiditate saepe sapiente aperiam nisi sequi maiores debitis quisquam est eaque dicta tempore aut reprehenderit asperiores esse excepturi autem, perspiciatis accusantium ut commodi ullam, laborum, dolorum magni similique. Quo nam esse fugit perspiciatis rerum at quia necessitatibus voluptatibus quaerat dolore suscipit illo, provident eveniet perferendis sed, assumenda ducimus maxime dolores architecto doloremque corporis reprehenderit doloribus. Fugiat magnam vero cum nostrum alias ipsam, cumque, iste ad ipsum blanditiis beatae distinctio nihil nam. Similique odit et unde mollitia nisi iusto aspernatur ad commodi impedit sit ab, ut, ratione, porro architecto illum. Deserunt hic temporibus doloremque aliquid maiores. Amet unde quia sint sit repudiandae totam, laudantium reprehenderit, veniam molestias tempore eligendi sequi corporis repellat ex soluta. Saepe ea rem minus quaerat officia, pariatur facilis officiis quod doloribus adipisci dolore ipsam recusandae quo repudiandae molestias illo nemo, ipsa totam. Dolorem corrupti autem est a, vel, quis voluptatum sapiente cupiditate ipsam consectetur animi mollitia aliquid neque sequi similique at ad voluptatem iure iste veritatis laudantium! Magnam, quisquam distinctio itaque dicta ut amet labore doloribus tempora quae debitis sequi exercitationem harum quos consequatur quidem nihil quasi iure illum, expedita a sint dolorum! Quidem repudiandae placeat voluptatibus voluptate porro?</p>
            </div>
        </div>
    </div>
    {/* About End */}
    </>
   );
}

export default Service;