import './CPAdmin.css';
import { useState } from 'react';
import { _userapiurl } from '../../APIUrlss';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function CPAdmin() {

  const navigate = useNavigate();  
  const [ output , setOutput ] = useState();  
  const [ opass , setOldPassword ] = useState();
  const [ npass , setNewPassword ] = useState();    
  const [ cnpass , setConfirmNewPassword ] = useState();

  const handlesubmit=()=>{
    var condition_obj={"email":localStorage.getItem("email"),"password":opass};
    axios.get(_userapiurl+"fetch",{
        params : { condition_obj : condition_obj }
    }).then((response)=>{
        if(npass==cnpass)
        {
            var update_details={"condition_obj":{"email":localStorage.getItem("email")} ,"content_obj":{"password":cnpass}};
            axios.patch(_userapiurl+"update",update_details).then((response)=>{
                alert("Profile password edited successfully....");
                navigate("/cpadmin");
                setOldPassword("");
                setNewPassword("");
                setConfirmNewPassword("");
            });
        }
        else
        {
            setOutput("New & confirm new password mismatch....");
            setNewPassword("");
            setConfirmNewPassword("");    
        }    
    }).catch((error)=>{
        setOutput("Invalid old password please try again....");
        setOldPassword("");    
    });
  };

  return (
    <>
        {/* About Start */}
        <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
<h1 class="display-5 mb-4">Change Password <span class="text-primary">Here</span></h1>
<font color="black">{output}</font>
<form>
  <div class="form-group">
    <label for="opass">Old Password:</label>
    <input type="password" class="form-control" value={opass} onChange={ e => setOldPassword(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="npass">New Password:</label>
    <input type="password" class="form-control" value={npass} onChange={ e => setNewPassword(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="cnpass">Confirm New Password:</label>
    <input type="password" class="form-control" value={cnpass} onChange={ e => setConfirmNewPassword(e.target.value) } />
  </div>
  <br/>
  <button type="button" class="btn btn-success" onClick={ ()=> handlesubmit() }>Submit</button>
</form>                
            </div>
        </div>
    </div>
    {/* About End */}
    </>
   );
}

export default CPAdmin;