import './Login.css';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { _userapiurl } from '../../APIUrlss';
import axios from 'axios';

function Login() {
  
  const navigate = useNavigate();  
  const [ email , setEmail ] = useState();    
  const [ password , setPassword ] = useState();
  const [ output , setOutput ] = useState();

  const handlesubmit=()=>{

    const userDetails={"email":email,"password":password};
    
    axios.post(_userapiurl+"login",userDetails).then((response)=>{
        const obj = response.data;
        const user = obj.user;
        localStorage.setItem("token",obj.token);
        localStorage.setItem("_id",user._id);
        localStorage.setItem("name",user.name);
        localStorage.setItem("email",user.email);
        localStorage.setItem("mobile",user.mobile);
        localStorage.setItem("address",user.address);
        localStorage.setItem("city",user.city);
        localStorage.setItem("gender",user.gender);
        localStorage.setItem("info",user.info);
        localStorage.setItem("role",user.role);

        (user.role=="admin")?navigate("/admin"):navigate("/user");

    }).catch((error)=>{
        setOutput("Invalid user or please verify your account....");
        setEmail("");
        setPassword("");    
    });
  
    };
  
  return (
    <>
            {/* About Start */}
            <div class="container-fluid bg-secondary p-0">
        <div class="row g-0">
            <div class="col-lg-12 py-6 px-5">
<h1 class="display-5 mb-4">Login <span class="text-primary">Here</span></h1>
<font color="blue">{output}</font>
<form>
  <div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" value={email} onChange={ e => setEmail(e.target.value) } />
  </div>
  <br/>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" value={password} onChange={ e => setPassword(e.target.value) } />
  </div>
  <br/>
  <button type="button" class="btn btn-success" onClick={ ()=> handlesubmit() }>Submit</button>
</form>                
            </div>
        </div>
    </div>
    {/* About End */}
    </>
   );
}

export default Login;