import rs from 'randomstring';

console.log(rs.generate(100))
